OIC Quiz - install as a phone app (works offline)
==================================================
Files: index.html, manifest.json, sw.js, icon-192.png, icon-512.png, icon-maskable-512.png
(keep them together in the SAME folder)

Option A - Netlify Drop (easiest, ~1 minute)
 1. Open https://app.netlify.com/drop
 2. Drag this whole folder onto the page. You get a link (https://...).

Option B - GitHub Pages
 1. Create a new public repository, upload all the files.
 2. Settings > Pages > Deploy from branch > main / (root).
 3. Open https://<your-user>.github.io/<repo>/

Then on the phone:
 - Android Chrome: open the link, menu (3 dots) > "Install app" / "Add to Home screen".
 - iPhone Safari: open the link, Share > "Add to Home Screen".
Open it once with internet. After that it works offline (including the PDF/Word readers).

Note: your tests/scores are stored in the browser of THAT address. Use "Export backup"
in the app to move data between devices.
